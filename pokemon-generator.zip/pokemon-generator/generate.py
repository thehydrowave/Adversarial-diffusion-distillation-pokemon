import torch
from diffusers import DDIMScheduler
from PIL import Image

def generate_images(prompt, student_unet, tokenizer, text_encoder, vae, device, num_inference_steps=10):
    student_unet.eval()
    scheduler = DDIMScheduler.from_pretrained("CompVis/stable-diffusion-v1-4", subfolder="scheduler")
    scheduler.set_timesteps(num_inference_steps)

    input_ids = tokenizer(prompt, return_tensors="pt").input_ids.to(device)
    encoder_hidden_states = text_encoder(input_ids)[0]

    latents = torch.randn((1, student_unet.in_channels, 64, 64)).to(device)
    for t in scheduler.timesteps:
        latent_model_input = scheduler.scale_model_input(latents, t)
        noise_pred = student_unet(latent_model_input, t, encoder_hidden_states).sample
        latents = scheduler.step(noise_pred, t, latents).prev_sample

    with torch.no_grad():
        images = vae.decode(latents / 0.18215).sample

    image = (images.clamp(-1, 1) + 1) / 2
    image = image.cpu().permute(0, 2, 3, 1).squeeze().numpy()
    return Image.fromarray((image * 255).astype("uint8"))
