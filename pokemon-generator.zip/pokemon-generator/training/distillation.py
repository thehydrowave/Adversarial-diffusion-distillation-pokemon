import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from diffusers import UNet2DConditionModel
from models.discriminator import Discriminator
from training.losses import noise_distillation_loss, adversarial_loss, discriminator_loss

def train_add(
    dataloader,
    teacher_unet: UNet2DConditionModel,
    student_unet: UNet2DConditionModel,
    tokenizer,
    text_encoder,
    noise_scheduler,
    vae,
    num_epochs,
    device,
    lr=1e-4,
):
    discriminator = Discriminator().to(device)
    optimizer_G = torch.optim.Adam(student_unet.parameters(), lr=lr)
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=lr)

    teacher_unet.eval()
    for epoch in range(num_epochs):
        pbar = tqdm(dataloader, desc=f"Epoch {epoch+1}/{num_epochs}")
        for batch in pbar:
            images = batch["pixel_values"].to(device)
            prompts = batch["caption"]

            # Encode images with the VAE before feeding them to UNet
            with torch.no_grad():
                images = vae.encode(images).latent_dist.sample() * 0.18215

            input_ids = tokenizer(prompts, return_tensors="pt", padding=True, truncation=True).input_ids.to(device)
            encoder_hidden_states = text_encoder(input_ids)[0]

            noise = torch.randn_like(images)
            timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps, (images.size(0),), device=device).long()
            noisy_images = noise_scheduler.add_noise(images, noise, timesteps)

            with torch.no_grad():
                teacher_pred = teacher_unet(noisy_images, timesteps, encoder_hidden_states).sample

            student_pred = student_unet(noisy_images, timesteps, encoder_hidden_states).sample

            L_distill = noise_distillation_loss(student_pred, teacher_pred)
            L_adv = adversarial_loss(student_pred, discriminator)
            G_loss = L_distill + 0.1 * L_adv

            optimizer_G.zero_grad()
            G_loss.backward()
            optimizer_G.step()

            D_loss = discriminator_loss(teacher_pred, student_pred, discriminator)

            optimizer_D.zero_grad()
            D_loss.backward()
            optimizer_D.step()

            pbar.set_postfix({
                "L_distill": L_distill.item(),
                "L_adv": L_adv.item(),
                "D_loss": D_loss.item()
            })

    return student_unet
