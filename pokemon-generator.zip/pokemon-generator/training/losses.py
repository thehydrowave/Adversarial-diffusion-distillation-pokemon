import torch
import torch.nn.functional as F

def noise_distillation_loss(student_pred, teacher_pred):
    return F.mse_loss(student_pred, teacher_pred)

def adversarial_loss(student_output, discriminator):
    d_output = discriminator(student_output)
    return F.binary_cross_entropy(d_output, torch.ones_like(d_output))

def discriminator_loss(real_imgs, fake_imgs, discriminator):
    real_logits = discriminator(real_imgs)
    fake_logits = discriminator(fake_imgs.detach())

    real_loss = F.binary_cross_entropy(real_logits, torch.ones_like(real_logits))
    fake_loss = F.binary_cross_entropy(fake_logits, torch.zeros_like(fake_logits))

    return (real_loss + fake_loss) / 2
