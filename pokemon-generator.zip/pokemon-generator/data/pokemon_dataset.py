import os
from torch.utils.data import Dataset
from PIL import Image
import pandas as pd
from torchvision import transforms

class PokemonDataset(Dataset):
    def __init__(self, image_dir, csv_file, image_size=256):
        self.image_dir = image_dir
        self.df = pd.read_csv(csv_file)
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5]),
        ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        name = row["Name"]
        type1 = row["Type1"]
        type2 = row["Type2"] if pd.notna(row["Type2"]) else ""
        evo = row["Evolution"] if pd.notna(row["Evolution"]) else ""

        types = f"{type1} and {type2}" if type2 else type1
        caption = f"A {types} Pokémon named {name}"
        if evo:
            caption += f" that evolves into {evo}"

        image_path = os.path.join(self.image_dir, f"{name}.png")  # Or .jpg depending on your files
        image = Image.open(image_path).convert("RGB")
        image = self.transform(image)

        return {
            "pixel_values": image,
            "caption": caption
        }
