import torch
import clip
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
from torchvision.datasets.folder import default_loader
from scipy.linalg import sqrtm
import numpy as np

def compute_clip_score(images, prompts, device="cuda"):
    model, preprocess = clip.load("ViT-B/32", device=device)
    images_preprocessed = torch.stack([preprocess(img).to(device) for img in images])
    text_tokens = clip.tokenize(prompts).to(device)

    with torch.no_grad():
        image_features = model.encode_image(images_preprocessed)
        text_features = model.encode_text(text_tokens)

    image_features /= image_features.norm(dim=-1, keepdim=True)
    text_features /= text_features.norm(dim=-1, keepdim=True)
    similarity = (image_features * text_features).sum(dim=-1)

    return similarity.mean().item()

def calculate_fid(real_features, generated_features):
    mu1, sigma1 = real_features.mean(0), np.cov(real_features, rowvar=False)
    mu2, sigma2 = generated_features.mean(0), np.cov(generated_features, rowvar=False)

    diff = mu1 - mu2
    covmean = sqrtm(sigma1.dot(sigma2))

    if np.iscomplexobj(covmean):
        covmean = covmean.real

    fid = diff.dot(diff) + np.trace(sigma1 + sigma2 - 2 * covmean)
    return fid

def extract_features(images, inception_model):
    features = []
    for img in images:
        img = img.resize((299, 299)).convert("RGB")
        img = ToTensor()(img).unsqueeze(0) * 2 - 1
        img = img.to(next(inception_model.parameters()).device)
        with torch.no_grad():
            feat = inception_model(img)[0].view(-1).cpu().numpy()
        features.append(feat)
    return np.array(features)
